import tkinter as tk
from tkinter import messagebox
from tkcalendar import DateEntry
from datetime import date

root = tk.Tk()
root.title("Registration Form")
root.geometry("500x650")
root.configure(bg="lightblue")

tk.Label(
    root,
    text="REGISTRATION FORM",
    font=("Arial", 20, "bold"),
    bg="lightblue"
).pack(pady=15)

# First Name
tk.Label(root, text="First Name:", bg="lightblue").pack()
first_name = tk.Entry(root, width=30)
first_name.pack(pady=5)

# Last Name
tk.Label(root, text="Last Name:", bg="lightblue").pack()
last_name = tk.Entry(root, width=30)
last_name.pack(pady=5)

# Gender
tk.Label(root, text="Gender:", bg="lightblue").pack()

gender = tk.StringVar(value="Male")

tk.Radiobutton(
    root, text="Male", variable=gender,
    value="Male", bg="lightblue"
).pack()

tk.Radiobutton(
    root, text="Female", variable=gender,
    value="Female", bg="lightblue"
).pack()

# Date of Birth
tk.Label(root, text="Date of Birth:", bg="lightblue").pack(pady=5)

dob = DateEntry(
    root,
    width=25,
    background="darkblue",
    foreground="white",
    date_pattern="dd-mm-yyyy",
    mindate=date(1950, 10, 1),
    maxdate=date.today()
)
dob.pack(pady=5)

# Hobbies
tk.Label(root, text="Hobbies:", bg="lightblue").pack(pady=8)

hobbies = [
    "Playing Cricket",
    "Watching TV",
    "Reading Books",
    "Listening Music",
    "Travelling to New Places"
]

hobby_vars = []

for hobby in hobbies:
    var = tk.IntVar()
    tk.Checkbutton(
        root,
        text=hobby,
        variable=var,
        bg="lightblue"
    ).pack(anchor="w", padx=130)
    hobby_vars.append(var)

# Submit Function
def submit():
    fname = first_name.get().strip()
    lname = last_name.get().strip()

    if fname == "" or lname == "":
        messagebox.showwarning(
            "Warning",
            "Please enter First Name and Last Name"
        )
    else:
        messagebox.showinfo(
            "Information",
            f"Welcome {fname} {lname}"
        )

# Submit Button
tk.Button(
    root,
    text="SUBMIT",
    command=submit,
    bg="blue",
    fg="white",
    font=("Arial", 12, "bold"),
    width=15
).pack(pady=20)

root.mainloop()