
import tkinter as tk
from tkinter import messagebox

# Main Window
root = tk.Tk()
root.title("User Login Page")
root.geometry("450x350")
root.configure(bg="lightblue")

# Heading
heading = tk.Label(
    root,
    text="USER LOGIN",
    font=("Arial", 22, "bold"),
    bg="lightblue"
)
heading.pack(pady=25)

# CNIC Label and Field
tk.Label(
    root,
    text="CNIC:",
    font=("Arial", 12),
    bg="lightblue"
).pack()

cnic = tk.Entry(root, width=30, font=("Arial", 12))
cnic.pack(pady=8)

# Password Label and Field
tk.Label(
    root,
    text="Password:",
    font=("Arial", 12),
    bg="lightblue"
).pack()

password = tk.Entry(root, width=30, font=("Arial", 12), show="*")
password.pack(pady=8)

# Login Function
def login():
    entered_cnic = cnic.get().replace("-", "").strip()
    entered_password = password.get().strip()

    if entered_cnic == "" or entered_password == "":
        messagebox.showwarning("Warning", "Please fill all fields")

    elif entered_cnic == "1234512345671" and entered_password == "12345":
        messagebox.showinfo("Success", "Login Successful!")

    else:
        messagebox.showerror("Error", "Invalid CNIC or Password")

# Login Button
login_button = tk.Button(
    root,
    text="LOGIN",
    command=login,
    bg="blue",
    fg="white",
    font=("Arial", 12, "bold"),
    width=15
)
login_button.pack(pady=20)

# Run Application
root.mainloop()