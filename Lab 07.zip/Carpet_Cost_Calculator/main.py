
import tkinter as tk
from tkinter import messagebox
from datetime import datetime

# Carpet Prices (Per Square Foot)
prices = {
    "Normal": 500,
    "Premium": 800,
    "Luxury": 1200
}

# Main Window
root = tk.Tk()
root.title("Carpet Cost Calculator")
root.state("zoomed")
root.configure(bg="#F0F4F8")
root.resizable(False, False)

# Heading
heading = tk.Label(
    root,
    text="CARPET COST CALCULATOR",
    font=("Arial", 22, "bold"),
    bg="#F0F4F8",
    fg="#154360"
)
heading.pack(pady=20)

welcome = tk.Label(
    root,
    text="Welcome to Carpet Seller Shop",
    font=("Arial", 14),
    bg="#F0F4F8"
)
welcome.pack(pady=5)

# Input Frame
frame = tk.Frame(root, bg="white", padx=30, pady=20)
frame.pack(pady=15)

# Length
tk.Label(
    frame,
    text="Carpet Length (feet):",
    font=("Arial", 12),
    bg="white"
).grid(row=0, column=0, pady=12, sticky="w")

length_entry = tk.Entry(frame, font=("Arial", 12), width=20)
length_entry.grid(row=0, column=1, padx=15)

# Width
tk.Label(
    frame,
    text="Carpet Width (feet):",
    font=("Arial", 12),
    bg="white"
).grid(row=1, column=0, pady=12, sticky="w")

width_entry = tk.Entry(frame, font=("Arial", 12), width=20)
width_entry.grid(row=1, column=1, padx=15)

# Carpet Type
tk.Label(
    frame,
    text="Select Carpet Type:",
    font=("Arial", 12),
    bg="white"
).grid(row=2, column=0, pady=12, sticky="w")

carpet_type = tk.StringVar(value="Normal")

carpet_menu = tk.OptionMenu(
    frame,
    carpet_type,
    "Normal",
    "Premium",
    "Luxury"
)
carpet_menu.config(width=16, font=("Arial", 11))
carpet_menu.grid(row=2, column=1, padx=15)

# Store calculated data
invoice_data = {}


# Calculate Function
def calculate_price():

    invoice_data.clear()

    try:
        length = float(length_entry.get())
        width = float(width_entry.get())

        if length <= 0 or width <= 0:
            messagebox.showerror(
                "Invalid Input",
                "Length and width must be greater than zero."
            )
            return False

        selected_type = carpet_type.get()

        # Calculate Area
        area = length * width

        # Get Carpet Rate
        rate = prices[selected_type]

        # Calculate Base Cost
        base_cost = area * rate

        # Calculate Tax
        if base_cost < 30000:
            tax_rate = 0.10
        else:
            tax_rate = 0.15

        tax = base_cost * tax_rate

        # Calculate Final Cost
        final_cost = base_cost + tax

        # Save Invoice Details
        invoice_data.update({
            "length": length,
            "width": width,
            "type": selected_type,
            "area": area,
            "rate": rate,
            "base": base_cost,
            "tax_rate": tax_rate,
            "tax": tax,
            "final": final_cost
        })

        # Display Result
        result_label.config(
            text=(
                f"Area: {area:.2f} sq.ft\n"
                f"Base Cost: Rs. {base_cost:,.2f}\n"
                f"Tax: {tax_rate * 100:.0f}%\n"
                f"Tax Amount: Rs. {tax:,.2f}\n"
                f"Final Cost: Rs. {final_cost:,.2f}"
            ),
            fg="#196F3D"
        )

        return True

    except ValueError:
        messagebox.showerror(
            "Invalid Input",
            "Please enter valid numeric values."
        )
        return False


# Invoice Function
def generate_invoice():

    if not invoice_data:
        messagebox.showwarning(
            "Warning",
            "Please calculate the price first."
        )
        return

    bill = tk.Toplevel(root)
    bill.title("Carpet Shop Invoice")
    bill.geometry("480x600")
    bill.configure(bg="white")
    bill.resizable(False, False)

    # Invoice Heading
    tk.Label(
        bill,
        text="CARPET SHOP",
        font=("Arial", 24, "bold"),
        bg="white",
        fg="#154360"
    ).pack(pady=(20, 5))

    tk.Label(
        bill,
        text="CUSTOMER INVOICE",
        font=("Arial", 15, "bold"),
        bg="white",
        fg="#2874A6"
    ).pack(pady=5)

    # Invoice Date
    date_text = datetime.now().strftime("%d-%m-%Y %H:%M")

    tk.Label(
        bill,
        text=f"Date: {date_text}",
        font=("Arial", 10),
        bg="white"
    ).pack(pady=5)

    # Invoice Details
    details = f"""
--------------------------------
       CARPET PURCHASE BILL
--------------------------------

Carpet Type: {invoice_data['type']}

Length: {invoice_data['length']} feet

Width: {invoice_data['width']} feet

Area: {invoice_data['area']:.2f} sq.ft

Price per sq.ft: Rs. {invoice_data['rate']:,.2f}

--------------------------------

Base Cost: Rs. {invoice_data['base']:,.2f}

Tax ({invoice_data['tax_rate'] * 100:.0f}%):
Rs. {invoice_data['tax']:,.2f}

--------------------------------

FINAL AMOUNT:

Rs. {invoice_data['final']:,.2f}

--------------------------------

          THANK YOU!

        VISIT AGAIN
--------------------------------
"""

    tk.Label(
        bill,
        text=details,
        font=("Consolas", 11),
        justify="left",
        bg="white",
        fg="#333333"
    ).pack(pady=15)


# Buttons Frame
button_frame = tk.Frame(root, bg="#F0F4F8")
button_frame.pack(pady=15)

# Calculate Button
calculate_button = tk.Button(
    button_frame,
    text="CALCULATE PRICE",
    font=("Arial", 11, "bold"),
    bg="#2874A6",
    fg="white",
    width=18,
    command=calculate_price
)
calculate_button.grid(row=0, column=0, padx=10)

# Invoice Button
invoice_button = tk.Button(
    button_frame,
    text="GENERATE INVOICE",
    font=("Arial", 11, "bold"),
    bg="#239B56",
    fg="white",
    width=18,
    command=generate_invoice
)
invoice_button.grid(row=0, column=1, padx=10)

# Result Label
result_label = tk.Label(
    root,
    text="Enter carpet details and calculate price.",
    font=("Arial", 12),
    bg="#F0F4F8",
    fg="#333333",
    justify="center"
)
result_label.pack(pady=15)

# Footer
footer = tk.Label(
    root,
    text="Carpet Seller Shop | Thank You",
    font=("Arial", 10),
    bg="#F0F4F8",
    fg="#777777"
)
footer.pack(side="bottom", pady=15)

# Run Application
root.mainloop()

