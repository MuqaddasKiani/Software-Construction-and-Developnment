
import tkinter as tk
import ast
import operator

# Main Window
root = tk.Tk()
root.title("Calculator")
root.state("zoomed")
root.resizable(True, True)
root.configure(bg="#eeeeee")

# Calculator Frame
frame = tk.Frame(root, bg="#eeeeee", padx=8, pady=8)
frame.pack(fill="both", expand=True)

# Display
display = tk.Entry(
    frame,
    font=("Arial", 23),
    justify="right",
    bd=4,
    relief="sunken",
    bg="white"
)
display.grid(
    row=0, column=0, columnspan=5,
    padx=3, pady=8, ipady=8, sticky="nsew"
)

# Safe Calculation
def calculate_expression(expression):
    operations = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv
    }

    def evaluate(node):
        if isinstance(node, ast.Constant):
            if type(node.value) in (int, float):
                return node.value
            raise ValueError("Invalid input")

        elif isinstance(node, ast.BinOp):
            op = operations.get(type(node.op))
            if op is None:
                raise ValueError("Invalid operation")
            return op(evaluate(node.left), evaluate(node.right))

        elif isinstance(node, ast.UnaryOp):
            if isinstance(node.op, ast.USub):
                return -evaluate(node.operand)
            elif isinstance(node.op, ast.UAdd):
                return evaluate(node.operand)

        raise ValueError("Invalid expression")

    tree = ast.parse(expression, mode="eval")
    return evaluate(tree.body)


# Button Functions
def add_to_display(value):
    display.insert(tk.END, value)


def clear_all():
    display.delete(0, tk.END)


def clear_entry():
    current = display.get()
    display.delete(0, tk.END)
    display.insert(0, current[:-1])


def calculate():
    try:
        expression = display.get()

        if not expression:
            return

        result = calculate_expression(expression)

        display.delete(0, tk.END)
        display.insert(0, str(result))

    except Exception:
        display.delete(0, tk.END)
        display.insert(0, "Error")


# Calculator Buttons
buttons = [
    ("7", 1, 0), ("8", 1, 1), ("9", 1, 2),
    ("/", 1, 3), ("CE", 1, 4),

    ("4", 2, 0), ("5", 2, 1), ("6", 2, 2),
    ("*", 2, 3), ("C", 2, 4),

    ("1", 3, 0), ("2", 3, 1), ("3", 3, 2),
    ("-", 3, 3),

    ("0", 4, 0), (".", 4, 2),
    ("+", 4, 3)
]

# Create Buttons
for (text, row, col) in buttons:

    if text == "CE":
        command = clear_entry
    elif text == "C":
        command = clear_all
    else:
        command = lambda value=text: add_to_display(value)

    button = tk.Button(
        frame,
        text=text,
        font=("Arial", 16),
        bg="white",
        activebackground="#dddddd",
        command=command,
        relief="raised"
    )

    if text == "0":
        button.grid(
            row=row, column=col, columnspan=2,
            padx=3, pady=3, sticky="nsew"
        )
    else:
        button.grid(
            row=row, column=col,
            padx=3, pady=3, sticky="nsew"
        )


# Equal Button
equal_button = tk.Button(
    frame,
    text="=",
    font=("Arial", 18),
    bg="white",
    activebackground="#dddddd",
    command=calculate
)

equal_button.grid(
    row=3, column=4, rowspan=2,
    padx=3, pady=3, sticky="nsew"
)

# Grid Configuration
for col in range(5):
    frame.grid_columnconfigure(col, weight=1)

for row in range(1, 5):
    frame.grid_rowconfigure(row, weight=1)

# Run Calculator
root.mainloop()
