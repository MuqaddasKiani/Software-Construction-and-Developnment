
class TooHotCoffeeCup(Exception):
    pass


class TooColdCoffeeCup(Exception):
    pass


try:
    temperature = float(input("Enter coffee temperature: "))

    if temperature >= 85:
        raise TooHotCoffeeCup("Too Hot Coffee Cup")

    elif temperature <= 65:
        raise TooColdCoffeeCup("Too Cold Coffee Cup")

    else:
        print("Coffee temperature is normal.")

except TooHotCoffeeCup as e:
    print("Exception:", e)

except TooColdCoffeeCup as e:
    print("Exception:", e)
