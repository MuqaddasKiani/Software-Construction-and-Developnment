
class LowHemoglobin(Exception):
    pass


class HighHemoglobin(Exception):
    pass


try:
    print("Hemoglobin Level Checker")

    gender = input("Enter gender (male/female/child): ").lower()
    hb = float(input("Enter Hemoglobin (Hb) level: "))

    if gender == "male":
        if hb < 13.5:
            raise LowHemoglobin("Low Hemoglobin Level")
        elif hb > 17.5:
            raise HighHemoglobin("High Hemoglobin Level")

    elif gender == "female":
        if hb < 12:
            raise LowHemoglobin("Low Hemoglobin Level")
        elif hb > 15.5:
            raise HighHemoglobin("High Hemoglobin Level")

    elif gender == "child":
        if hb < 11:
            raise LowHemoglobin("Low Hemoglobin Level")
        elif hb > 16:
            raise HighHemoglobin("High Hemoglobin Level")

    else:
        print("Invalid gender")
        raise SystemExit

    print("Hemoglobin level is Normal.")

except LowHemoglobin as e:
    print("Exception:", e)

except HighHemoglobin as e:
    print("Exception:", e)
